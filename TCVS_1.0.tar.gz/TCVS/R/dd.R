#' @name dd
#' @title Example Microbiome Dataset
#' @description A dataset containing the counts of 856 taxa from an upper-respiratory-tract microbiome study.
#' @docType data
#' @usage data(DirMultOutput)
#' @format An object of class `list`.
#' @keywords datasets
NULL