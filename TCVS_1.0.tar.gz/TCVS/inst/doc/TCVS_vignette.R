## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,   
  results = 'markup', 
  warning = FALSE,
  message = FALSE 
)

## ----download and load--------------------------------------------------------
#install.packages("TCVS_1.0.tar.gz", repos=NULL)
library(TCVS)

## ----load-data----------------------------------------------------------------
library(CVXR)
library(knockoff)
library(GUniFrac)
library(cluster)
library(dirmult)
data(P_60, package = "TCVS")
dim(P)
data(throat.tree, package = "GUniFrac")
data(throat.otu.tab, package = "GUniFrac")
data(DirMultOutput, package = "TCVS")

## ----generate_data------------------------------------------------------------
n = 200
p = 60
setting = 1
q = 0.05
method = "BIC"
loop_start_index = 1
seed = 2023
type = "Dirmult" # type to generate compositional data
normalizeMethod = "Rowsum"
beta.slack.factor = NULL
pseudocount = 0.5
maxlam = 0.1
minlam = 1e-7
nlam = 20
X <- get.all.OTU(n, p, trans = 0, type, normalizeMethod, pseudocount, seed = seed)
# clr transformation
Z <- get.all.OTU(n, p, trans = 2, type, normalizeMethod, pseudocount, seed = seed) 
y <- get.all.y(Z, setting = setting, beta.slack.factor, seed = seed)
dim(Z)

## ----variable selection-------------------------------------------------------
result.TCVS <- TCVS(
  X = X,
  Z = Z,
  y = y,
  P = P,
  method = method,
  maxlam,
  minlam,
  nlam,
  q = q,
  seed = seed
)
selected.OTU = which(result.TCVS$S.TCVS!=0)
selected.OTU # selected OTUs using TCVS

